// Lista de sites que serão redirecionados para o ComparaPreço
const SITES_ALVO = [
  "mercadolivre.com.br",
  "mercadolivre.com",
  "amazon.com.br",
  "magazineluiza.com.br"
];

// Só redireciona uma vez por sessão para não ser chato
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  // Ignora se não for a aba principal
  if (details.frameId !== 0) return;

  const url = new URL(details.url);
  const hostname = url.hostname.replace("www.", "");

  // Verifica se é um site alvo
  const ehAlvo = SITES_ALVO.some(site => hostname.includes(site));
  if (!ehAlvo) return;

  // Verifica se já redirecionou este site nesta sessão
  chrome.storage.session.get([hostname], (result) => {
    if (result[hostname]) return; // Já redirecionou, deixa passar

    // Salva que já redirecionou para não entrar em loop
    chrome.storage.session.set({ [hostname]: true });

    // Redireciona para seu site com o link original como parâmetro
    const destino = `https://comparapreco.github.io/?origem=${encodeURIComponent(details.url)}&site=${hostname}`;
    chrome.tabs.update(details.tabId, { url: destino });
  });
}, { url: [{ schemes: ["http", "https"] }] });
